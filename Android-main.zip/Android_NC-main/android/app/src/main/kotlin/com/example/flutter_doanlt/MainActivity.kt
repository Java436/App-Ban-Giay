package com.example.flutter_doanlt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
